using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        Console.WriteLine("Velkommen til spørreundersøkelsen!");

        // Opprett et dictionary for å lagre spørsmål og svar
        Dictionary<string, string> spørsmålOgSvar = new Dictionary<string, string>();

        while (true)
        {
            // Be brukeren om et spørsmål
            Console.Write("Skriv inn et spørsmål (eller 'exit' for å avslutte): ");
            string spørsmål = Console.ReadLine();

            // Sjekk om brukeren ønsker å avslutte
            if (spørsmål.ToLower() == "exit")
                break;

            // Be brukeren om et svar
            Console.Write("Skriv inn et svar: ");
            string svar = Console.ReadLine();

            // Legg til spørsmål og svar i dictionary
            spørsmålOgSvar.Add(spørsmål, svar);
        }

        // Skriv ut resultatene
        Console.WriteLine("\nResultater:");
        foreach (var par in spørsmålOgSvar)
        {
            Console.WriteLine($"{par.Key}: {par.Value}");
        }
    }
}
