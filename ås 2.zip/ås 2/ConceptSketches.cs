using System;

namespace MyProject
{
    public class ConceptSketches
    {
        public void DrawSketch1()
        {
            Console.WriteLine("Sketch 1: [Beskrivelse av skissen]");
            // Legg til koden for den første skissen din her
        }

        public void DrawSketch2()
        {
            Console.WriteLine("Sketch 2: [Beskrivelse av skissen]");
            // Legg til koden for den andre skissen din her
        }

        // Fortsett å legge til metoder etter behov for andre skisser
    }
}
